def normalize(a, b):
    return [96.45523,93.2112344]